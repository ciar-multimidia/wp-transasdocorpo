<?php get_header(); ?>

<section class="container">
	<?php get_template_part('inc/home-noticias'); ?>
</section>

<?php get_template_part('inc/home-chamadas'); ?>

<section class="container">
	<?php get_template_part('inc/home-conteudo'); ?>
</section>

<?php get_footer(); ?>