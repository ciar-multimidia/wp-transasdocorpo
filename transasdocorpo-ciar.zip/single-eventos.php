<?php /* get_header(); ?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

			<article>
				<h1><a href="<?php the_permalink(); ?>"><?php the_title(''); ?></a></h1>
				<?php the_content('saiba mais...'); ?>
				Evento em <?php $timestamp = get_field('data_e_hora_evento');
      echo date_i18n("d/m/Y", $timestamp); ?> às <?php $timestamp = get_field('data_e_hora_evento');
      echo date_i18n("H:i", $timestamp); ?>
			</article>

<?php endwhile; ?>
<?php else : ?>
<?php endif; ?>	


<?php get_footer();*/ ?>


<?php get_header(); ?>

<section class="area-textos fix">
	<div class="container">

			
			<div class="col-conteudo">
				<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

							<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
								<header>
									<h2><span><?php printf( __( '%s', 'ciar-transasdocorpo' ), get_post_type( get_the_ID() ) ); ?></span>  Divulgado em <?php the_date(); ?>. Evento em <?php $timestamp = get_field('data_e_hora_evento'); echo date_i18n("d/m/Y", $timestamp); ?> (<?php $timestamp = get_field('data_e_hora_evento');
      echo date_i18n("H:i", $timestamp); ?>)</h2>
									<h1><a href="<?php the_permalink(); ?>"><?php the_title(''); ?></a></h1>
								</header>

								<?php the_content(); ?>

								<p>&nbsp;</p>	
								<hr>
								<h6 class="upper">Data do evento: <?php $timestamp = get_field('data_e_hora_evento'); echo date_i18n("d/m/Y", $timestamp); ?> às <?php $timestamp = get_field('data_e_hora_evento'); echo date_i18n("H:i", $timestamp); ?></h6>
								
							</article>

				<?php endwhile; endif; ?>
			</div>
			

			<div class="col-aside">
				<h3>Mais eventos</h3>
				<?php $args = array( 'post_parent' => $parent,  'post_type' => 'eventos',  'order' => 'DESC', 'posts_per_page' => 10, 'orderby' => 'meta_value_num', 'meta_key' => 'data_e_hora_evento', 'meta_type' => 'DATETIME' ); $my_query = new  WP_Query( $args ); while ( $my_query->have_posts() ) : $my_query->the_post(); ?>

					<li id="post-<?php the_ID(); ?>" <?php post_class('lista-item'); ?>><a href="<?php the_permalink(); ?>"><?php the_title(''); ?></a></li>
	    
				<?php endwhile; wp_reset_query(); ?>

				<p align="center"><a href="<?php bloginfo('url'); ?>/eventos" class="btn small">Ver todos os eventos</a></p>
			</div>
	</div>
</section>
<?php get_footer(); ?>