<?php get_header(); ?>

<section class="area-textos fix">
	<div class="container">

			<div class="col-conteudo full">
			

						<article class="post- type-biblioteca">
	
						<?php $args = array( 'post_parent' => $parent, 'post_type' => 'biblioteca', 'posts_per_page' => 1, 'sort_column'=> 'menu_order' ); $my_query = new  WP_Query( $args ); while ( $my_query->have_posts() ) : $my_query->the_post(); ?>

								<header>
									<h2><span><?php printf( __( '%s', 'ciar-transasdocorpo' ), get_post_type( get_the_ID() ) ); ?></span> Último publicado em <?php the_date(); ?></h2>
									<h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
								</header>			
								<p><?php echo wp_trim_words( get_the_content(), 150, '...' ); ?></p>
								<p><a href="<?php the_permalink(); ?>" class="btn-block"><span>Ler na integra</span></a></p>

								<div class="fix">&nbsp;</div>
						<?php endwhile; wp_reset_query(); ?>
						</article>
						
			</div>

			<div class="area-conteudo">
				<h3 class="block upper">Nossa biblioteca</h3>
				<?php $args = array( 'post_parent' => $parent, 'post_type' => array('artigos', 'publicacoes', 'informativos'), 'posts_per_page' => 6, 'orderby' => 'rand'); $my_query = new  WP_Query( $args ); while ( $my_query->have_posts() ) : $my_query->the_post(); ?>

					<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
						<header>
							<div class="tag">
								<?php printf( __( '%s', 'ciar-transasdocorpo' ), get_post_type( get_the_ID() ) ); ?>
							</div>
							<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
							<time><?php echo get_the_date(); ?></time>
						</header>

						<footer><a href="<?php the_permalink(); ?>" class="more-link">saiba mais</a></footer>
					</div>

				<?php endwhile; wp_reset_query(); ?>
			</div>

	</div>
</section>
<?php get_footer(); ?>


<?php /*?><?php get_header(); ?>

<article>
<h1>Biblioteca</h1>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

			
				<h3>- <a href="<?php the_permalink(); ?>"><?php the_title(''); ?></a></h3>

			

<?php endwhile; ?>
<?php // paginacao(); ?>
<?php else : ?>
<?php endif; ?>	

<br><br> <hr> <br><br>

<h1>Artigos</h1>

<?php $args = array( 'post_parent' => $parent, 'post_type' => 'artigos', 'posts_per_page' => 10, 'sort_column'=> 'menu_order' ); $my_query = new  WP_Query( $args ); while ( $my_query->have_posts() ) : $my_query->the_post(); ?>

				<h3>- <a href="<?php the_permalink(); ?>"><?php the_title(''); ?></a></h3>
	    
	<?php endwhile; wp_reset_query(); ?>
	<br>
	(<a href="<?php bloginfo('url'); ?>/artigos">Ver todos os artigos</a>) <br>


<br><br> <hr> <br><br>

<h1>Publicações</h1>

<?php $args = array( 'post_parent' => $parent, 'post_type' => 'publicacoes', 'posts_per_page' => 10, 'sort_column'=> 'menu_order' ); $my_query = new  WP_Query( $args ); while ( $my_query->have_posts() ) : $my_query->the_post(); ?>

				<h3>- <a href="<?php the_permalink(); ?>"><?php the_title(''); ?></a></h3>
	    
	<?php endwhile; wp_reset_query(); ?>
	<br>
	(<a href="<?php bloginfo('url'); ?>/publicacoes">Ver todas as publicações</a>) <br>	


<br><br> <hr> <br><br>

<h1>Informativos</h1>

<?php $args = array( 'post_parent' => $parent, 'post_type' => 'informativos', 'posts_per_page' => 2, 'sort_column'=> 'menu_order' ); $my_query = new  WP_Query( $args ); while ( $my_query->have_posts() ) : $my_query->the_post(); ?>

				<h3>- <a href="<?php the_permalink(); ?>"><?php the_title(''); ?></a></h3>
	    
	<?php  endwhile;  wp_reset_query(); ?>
	<br>
	(<a href="<?php bloginfo('url'); ?>/informativos">Ver todos os informativos</a>) <br>		
</article>

<?php get_footer(); ?><?php */?>